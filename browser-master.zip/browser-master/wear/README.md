Android Wear OS
===============

- The goal is to have a stand alone Android Wear app browsing the web.
- For now, not developed because Android Wear does not support WebView.
- A solution could by to browse JSON API and display views build on this JSON.
- A solution could be to do the same as the app com.appfour.wearbrowser.