package com.mercandalli.android.wear.browser.network

interface NetworkManager {

    fun isNetworkAvailable(): Boolean
}
