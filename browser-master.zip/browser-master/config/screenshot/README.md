## Requirements

- Install fastlane [here](https://docs.fastlane.tools/getting-started/android/setup/) 
    - `sudo gem install fastlane -NV`
    - export LANG=en_US.UTF-8
    - export LANGUAGE=en_US.UTF-8
    - export LC_ALL=en_US.UTF-8
- Install screengrab [here](https://docs.fastlane.tools/getting-started/android/screenshots/)
    - `sudo gem install screengrab`