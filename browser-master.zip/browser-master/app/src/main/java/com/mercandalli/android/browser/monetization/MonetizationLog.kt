package com.mercandalli.android.browser.monetization

interface MonetizationLog {

    fun d(tag: String, message: String)
}
