package com.mercandalli.android.browser.update

interface UpdateManager {

    fun isFirstLaunchAfterUpdate(): Boolean
}
