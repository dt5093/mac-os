package com.mercandalli.android.browser.toast

interface ToastManager {

    fun toast(message: String)

    fun toast(message: Int)
}
