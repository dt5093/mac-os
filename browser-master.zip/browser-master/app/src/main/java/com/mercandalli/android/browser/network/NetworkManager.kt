package com.mercandalli.android.browser.network

interface NetworkManager {

    fun isNetworkAvailable(): Boolean
}
