package com.mercandalli.android.browser.context

import androidx.test.InstrumentationRegistry

object ContextUtils {

    val context = InstrumentationRegistry.getInstrumentation().context!!
}
