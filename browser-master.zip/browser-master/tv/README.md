Android TV
==========

- For now, not developed
- The goal will be to have a browser experience without touch