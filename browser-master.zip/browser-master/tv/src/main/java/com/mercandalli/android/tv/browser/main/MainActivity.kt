package com.mercandalli.android.tv.browser.main

import android.app.Activity
import android.os.Bundle
import com.mercandalli.android.tv.browser.R

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
