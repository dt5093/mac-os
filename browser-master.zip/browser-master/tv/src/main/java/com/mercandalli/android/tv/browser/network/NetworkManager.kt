package com.mercandalli.android.tv.browser.network

interface NetworkManager {

    fun isNetworkAvailable(): Boolean
}
